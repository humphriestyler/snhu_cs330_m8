#define STB_IMAGE_IMPLEMENTATION
#include<stb/stb_image.h>