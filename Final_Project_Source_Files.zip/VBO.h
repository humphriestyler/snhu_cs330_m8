#ifndef VBO_CLASS_H
#define VBO_CLASS_H

#include <glad/glad.h>

class VBO {
public:

	// ID reference of Vertex Buffer Object
	GLuint ID;

	// Constructor that generates an Vertex Buffer Object
	VBO(GLfloat* vertices, GLsizeiptr size);

	// Binds the VBO
	void Bind();

	// Unbinds the VBO
	void Unbind();

	// Deletes the VBO
	void Delete();
};

#endif