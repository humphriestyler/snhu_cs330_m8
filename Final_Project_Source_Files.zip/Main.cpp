#include <iostream>
#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <stb/stb_image.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "Texture.h"
#include "shader.h"
#include "VAO.h"
#include "VBO.h"
#include "EBO.h"
#include "Camera.h"


// Predefined variables for camera width and height
const unsigned int width = 800;
const unsigned int height = 800;

// Vertices for ocean
GLfloat oceanVertices[] = {
	// Position, Color, Uv, Normal
	-1.5f, -0.1f, -1.5f,	0.0f, 0.0f, 0.0f,	0.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	1.5f, -0.1f, -1.5f,	0.0f, 0.0f, 0.0f,	1.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	1.5f, -0.1f, 1.5f,		0.0f, 0.0f, 0.0f,	1.0f, 1.0f,		0.0f, 1.0f, 0.0f,
	-1.5f, -0.1f, 1.5f,	0.0f, 0.0f, 0.0f,	0.0f, 1.0f,		0.0f, 1.0f, 0.0f
};

// Indices for ocean
GLuint oceanIndices[] = {
	0, 1, 2,
	2, 3, 0
};

// Vertices for ship base
GLfloat shipBaseVertices[] = {
	// Position, Color, UV, Normal
	-0.1f, -0.1f, -0.1f,	0.0f, 0.0f, 0.0f,    1.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, -0.1f, -0.1f,		0.0f, 0.0f, 0.0f,    0.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, -0.1f, 0.1f,		0.0f, 0.0f, 0.0f,    0.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, -0.1f, 0.1f,		0.0f, 0.0f, 0.0f,    1.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, 0.0f, -0.1f,		0.0f, 0.0f, 0.0f,    1.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, -0.1f,		0.0f, 0.0f, 0.0f,    0.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, 0.1f,		0.0f, 0.0f, 0.0f,    0.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, 0.0f, 0.1f,		0.0f, 0.0f, 0.0f,    1.0f, 1.0f,   0.0f, 1.0f, 0.0f
};

// Vertices for ship front
GLfloat shipFrontVertices[] = {
	// Position, Color, UV, Normal
	-0.1f, 0.0f, -0.3f,	0.0f, 0.0f, 0.0f,	1.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	0.1f, 0.0f, -0.3f,		0.0f, 0.0f, 0.0f,	0.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	0.1f, -0.1f, -0.1f,		0.0f, 0.0f, 0.0f,	0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	-0.1f, -0.1f, -0.1f,	0.0f, 0.0f, 0.0f,	1.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	-0.1f, 0.0f, -0.3f,	0.0f, 0.0f, 0.0f,	1.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	0.1f, 0.0f, -0.3f,		0.0f, 0.0f, 0.0f,	0.0f, 0.0f, 0.0f,	1.0f, 0.0f,
	0.1f, 0.0f, -0.1f,		0.0f, 0.0f, 0.0f,	0.0f, 1.0f, 0.0f,	1.0f, 0.0f,
	-0.1f, 0.0f, -0.1f,		0.0f, 0.0f, 0.0f,	1.0f, 1.0f, 0.0f,	1.0f, 0.0f
};

// Vertices for ship back
GLfloat shipBackVertices[] = {
	// Position, Color, UV, Normal
	-0.1f, -0.1f, 0.1f,		0.0f, 0.0f, 0.0f,	1.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	0.1f, -0.1f, 0.1f,		0.0f, 0.0f, 0.0f,	0.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	0.1f, -0.1f, 0.2f,		0.0f, 0.0f, 0.0f,	0.0f, 1.0f,		0.0f, 1.0f, 0.0f,
	-0.1f, -0.1f, 0.2f,		0.0f, 0.0f, 0.0f,	1.0f, 1.0f,		0.0f, 1.0f, 0.0f,
	-0.1f, 0.0f, 0.1f,		0.0f, 0.0f, 0.0f,	1.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, 0.1f,		0.0f, 0.0f, 0.0f,	0.0f, 0.0f,		0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, 0.3f,		0.0f, 0.0f, 0.0f,	0.0f, 1.0f,		0.0f, 1.0f, 0.0f,
	-0.1f, 0.0f, 0.3f,		0.0f, 0.0f, 0.0f,	1.0f, 1.0f,		0.0f, 1.0f, 0.0f,
};

// Vertices for ship top
GLfloat shipTopVertices[] = {
	// Position, Color, UV, Normal
	-0.1f, 0.0f, -0.25f,		0.0f, 0.0f, 0.0f,    1.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, -0.25f,		0.0f, 0.0f, 0.0f,    0.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.05f, 0.3f,		0.0f, 0.0f, 0.0f,    0.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, 0.05f, 0.3f,		0.0f, 0.0f, 0.0f,    1.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, 0.05f, -0.1f,		0.0f, 0.0f, 0.0f,    1.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.05f, -0.1f,		0.0f, 0.0f, 0.0f,    0.0f, 0.0f,   0.0f, 1.0f, 0.0f,
	0.1f, 0.0f, 0.3f,		0.0f, 0.0f, 0.0f,    0.0f, 1.0f,   0.0f, 1.0f, 0.0f,
	-0.1f, 0.0f, 0.3f,		0.0f, 0.0f, 0.0f,    1.0f, 1.0f,   0.0f, 1.0f, 0.0f
};

GLfloat mountain1Vertices[] = {
	// Bottom side
	1.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    0.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    5.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,

	// Left side
	0.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.5f, -1.0f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Non-facing side
	0.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.5f, -1.0f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Right side
	1.5f, -0.1f, -1.5f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.5f, -1.0f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     -0.8f, 0.5f, 0.0f,

	// Facing side
	1.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	0.5f, -0.1f, -0.5f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.f, 0.5f, -1.0f,      0.f, 0.f, 0.f,    2.5f, 5.0f,      -0.8f, 0.5f, 0.0f,
};

GLfloat mountain2Vertices[] = {
	// Bottom side
	1.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    0.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    5.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,

	// Left side
	0.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.25f, -0.25f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Non-facing side
	0.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.25f, -0.25f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Right side
	1.5f, -0.1f, -0.75f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.25f, -0.25f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     -0.8f, 0.5f, 0.0f,

	// Facing side
	1.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	0.5f, -0.1f, 0.25f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.25f, -0.25f,      0.f, 0.f, 0.f,    2.5f, 5.0f,   -0.8f, 0.5f, 0.0f,
};

GLfloat mountain3Vertices[] = {
	// Bottom side
	1.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    0.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    5.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,

	// Left side
	0.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.5f, 0.5f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Non-facing side
	0.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.5f, 0.5f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Right side
	1.5f, -0.1f, 0.0f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.5f, 0.5f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     -0.8f, 0.5f, 0.0f,

	// Facing side
	1.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	0.5f, -0.1f, 1.0f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.5f, 0.5f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     -0.8f, 0.5f, 0.0f,
};

GLfloat mountain4Vertices[] = {
	// Bottom side
	1.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    0.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    5.0f, 5.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,

	// Left side
	0.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	0.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.25f, 1.05f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Non-facing side
	0.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     0.0f, 0.0f, 0.0f,
	1.0f, 0.25f, 1.05f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     0.0f, 0.0f, 0.0f,

	// Right side
	1.5f, -0.1f, 0.55f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.25f, 1.05f,      0.f, 0.f, 0.f,    2.5f, 5.0f,     -0.8f, 0.5f, 0.0f,

	// Facing side
	1.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    5.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	0.5f, -0.1f, 1.55f,     0.f, 0.f, 0.f,    0.0f, 0.0f,     -0.8f, 0.5f, 0.0f,
	1.0f, 0.25f, 1.05f,      0.f, 0.f, 0.f,    2.5f, 5.0f,   -0.8f, 0.5f, 0.0f,
};

// Indices for ship front
GLuint shipFrontIndices[]{
	0, 1, 2, 2, 3, 0,   // Front face
	4, 5, 6, 6, 7, 4,   // Back face
	0, 4, 7, 7, 3, 0,   // Bottom face
	1, 5, 6, 6, 2, 1,   // Top face
	3, 2, 6, 6, 7, 3,   // Right face
	0, 1, 5, 5, 4, 0    // Left face
};

// Indices for ship base
GLuint shipBaseIndices[]{
	0, 1, 2, 2, 3, 0,   // Front face
	4, 5, 6, 6, 7, 4,   // Back face
	0, 4, 7, 7, 3, 0,   // Bottom face
	1, 5, 6, 6, 2, 1,   // Top face
	3, 2, 6, 6, 7, 3,   // Right face
	0, 1, 5, 5, 4, 0    // Left face
};

// Indices for ship base
GLuint shipBackIndices[]{
	0, 1, 2, 2, 3, 0,   // Front face
	4, 5, 6, 6, 7, 4,   // Back face
	0, 4, 7, 7, 3, 0,   // Bottom face
	1, 5, 6, 6, 2, 1,   // Top face
	3, 2, 6, 6, 7, 3,   // Right face
	0, 1, 5, 5, 4, 0    // Left face
};

// Indices for ship base
GLuint shipTopIndices[]{
	0, 1, 2, 2, 3, 0,   // Front face
	4, 5, 6, 6, 7, 4,   // Back face
	0, 4, 7, 7, 3, 0,   // Bottom face
	1, 5, 6, 6, 2, 1,   // Top face
	3, 2, 6, 6, 7, 3,   // Right face
	0, 1, 5, 5, 4, 0    // Left face
};

GLuint mountain1Indices[]{
	0, 1, 2,
	0, 2, 3,
	4, 6, 5,
	7, 9, 8,
	10, 12, 11,
	13, 15, 14
};

GLuint mountain2Indices[]{
	0, 1, 2,
	0, 2, 3,
	4, 6, 5,
	7, 9, 8,
	10, 12, 11,
	13, 15, 14
};

GLuint mountain3Indices[]{
	0, 1, 2,
	0, 2, 3,
	4, 6, 5,
	7, 9, 8,
	10, 12, 11,
	13, 15, 14
};

GLuint mountain4Indices[]{
	0, 1, 2,
	0, 2, 3,
	4, 6, 5,
	7, 9, 8,
	10, 12, 11,
	13, 15, 14
};

// Vertices for light cube
GLfloat lightVertices[] = {
	-0.1f, 1.9f,  0.1f,
	-0.1f, 1.9f, -0.1f,
	 0.1f, 1.9f, -0.1f,
	 0.1f, 1.9f,  0.1f,
	-0.1f, 2.1f,  0.1f,
	-0.1f, 2.1f, -0.1f,
	 0.1f, 2.1f, -0.1f,
	 0.1f, 2.1f,  0.1f
};

// Indices for light cube
GLuint lightIndices[] = {
	0, 1, 2,
	0, 2, 3,
	0, 4, 7,
	0, 7, 3,
	3, 7, 6,
	3, 6, 2,
	2, 6, 5,
	2, 5, 1,
	1, 5, 4,
	1, 4, 0,
	4, 5, 6,
	4, 6, 7
};

int main() {

	// Initialize GLFW
	glfwInit();

	// Determine GLFW version
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);

	// Determine CORE profile
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	// Create a GLFWwindow object of 800 by 800 pixels, naming it "YoutubeOpenGL"
	GLFWwindow* window = glfwCreateWindow(width, height, "YoutubeOpenGL", NULL, NULL);

	// Error check if the window fails to create
	if (window == NULL) {
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}

	// Introduce the window into the current context
	glfwMakeContextCurrent(window);

	//Load GLAD so it configures OpenGL
	gladLoadGL();

	// Specify the viewport of OpenGL in the Window
	glViewport(0, 0, width, height);

	// Generates Shader object using shaders default.vert and default.frag
	Shader shaderProgram("default.vert", "default.frag");

	// Generates VAO, VBO, EBO, and binds / unbinds all for the ocean plane
	VAO oceanVAO;
	oceanVAO.Bind();
	VBO oceanVBO(oceanVertices, sizeof(oceanVertices));
	EBO oceanEBO(oceanIndices, sizeof(oceanIndices));
	oceanVAO.LinkAttrib(oceanVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	oceanVAO.LinkAttrib(oceanVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	oceanVAO.LinkAttrib(oceanVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	oceanVAO.LinkAttrib(oceanVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	oceanVAO.Unbind();
	oceanVBO.Unbind();
	oceanEBO.Unbind();

	VAO shipBaseVAO;
	shipBaseVAO.Bind();
	VBO shipBaseVBO(shipBaseVertices, sizeof(shipBaseVertices));
	EBO shipBaseEBO(shipBaseIndices, sizeof(shipBaseIndices));
	shipBaseVAO.LinkAttrib(shipBaseVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	shipBaseVAO.LinkAttrib(shipBaseVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	shipBaseVAO.LinkAttrib(shipBaseVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	shipBaseVAO.LinkAttrib(shipBaseVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	shipBaseVAO.Unbind();
	shipBaseVBO.Unbind();
	shipBaseEBO.Unbind();

	VAO shipFrontVAO;
	shipFrontVAO.Bind();
	VBO shipFrontVBO(shipFrontVertices, sizeof(shipFrontVertices));
	EBO shipFrontEBO(shipFrontIndices, sizeof(shipFrontIndices));
	shipFrontVAO.LinkAttrib(shipFrontVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	shipFrontVAO.LinkAttrib(shipFrontVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	shipFrontVAO.LinkAttrib(shipFrontVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	shipFrontVAO.LinkAttrib(shipFrontVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	shipFrontVAO.Unbind();
	shipFrontVAO.Unbind();
	shipFrontVAO.Unbind();

	VAO shipBackVAO;
	shipBackVAO.Bind();
	VBO shipBackVBO(shipBackVertices, sizeof(shipBackVertices));
	EBO shipBackEBO(shipBackIndices, sizeof(shipBackIndices));
	shipBackVAO.LinkAttrib(shipBackVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	shipBackVAO.LinkAttrib(shipBackVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	shipBackVAO.LinkAttrib(shipBackVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	shipBackVAO.LinkAttrib(shipBackVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	shipBackVAO.Unbind();
	shipBackVAO.Unbind();
	shipBackVAO.Unbind();

	VAO shipTopVAO;
	shipTopVAO.Bind();
	VBO shipTopVBO(shipTopVertices, sizeof(shipTopVertices));
	EBO shipTopEBO(shipTopIndices, sizeof(shipTopIndices));
	shipTopVAO.LinkAttrib(shipTopVBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	shipTopVAO.LinkAttrib(shipTopVBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	shipTopVAO.LinkAttrib(shipTopVBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	shipTopVAO.LinkAttrib(shipTopVBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	shipTopVAO.Unbind();
	shipTopVAO.Unbind();
	shipTopVAO.Unbind();

	VAO mountain1VAO;
	mountain1VAO.Bind();
	VBO mountain1VBO(mountain1Vertices, sizeof(mountain1Vertices));
	EBO mountain1EBO(mountain1Indices, sizeof(mountain1Indices));
	mountain1VAO.LinkAttrib(mountain1VBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	mountain1VAO.LinkAttrib(mountain1VBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	mountain1VAO.LinkAttrib(mountain1VBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	mountain1VAO.LinkAttrib(mountain1VBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	mountain1VAO.Unbind();
	mountain1VAO.Unbind();
	mountain1VAO.Unbind();

	VAO mountain2VAO;
	mountain2VAO.Bind();
	VBO mountain2VBO(mountain2Vertices, sizeof(mountain2Vertices));
	EBO mountain2EBO(mountain2Indices, sizeof(mountain2Indices));
	mountain2VAO.LinkAttrib(mountain2VBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	mountain2VAO.LinkAttrib(mountain2VBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	mountain2VAO.LinkAttrib(mountain2VBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	mountain2VAO.LinkAttrib(mountain2VBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	mountain2VAO.Unbind();
	mountain2VAO.Unbind();
	mountain2VAO.Unbind();

	VAO mountain3VAO;
	mountain3VAO.Bind();
	VBO mountain3VBO(mountain3Vertices, sizeof(mountain3Vertices));
	EBO mountain3EBO(mountain3Indices, sizeof(mountain3Indices));
	mountain3VAO.LinkAttrib(mountain3VBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	mountain3VAO.LinkAttrib(mountain3VBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	mountain3VAO.LinkAttrib(mountain3VBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	mountain3VAO.LinkAttrib(mountain3VBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	mountain3VAO.Unbind();
	mountain3VAO.Unbind();
	mountain3VAO.Unbind();

	VAO mountain4VAO;
	mountain4VAO.Bind();
	VBO mountain4VBO(mountain4Vertices, sizeof(mountain4Vertices));
	EBO mountain4EBO(mountain4Indices, sizeof(mountain4Indices));
	mountain4VAO.LinkAttrib(mountain4VBO, 0, 3, GL_FLOAT, 11 * sizeof(float), (void*)0);
	mountain4VAO.LinkAttrib(mountain4VBO, 1, 3, GL_FLOAT, 11 * sizeof(float), (void*)(3 * sizeof(float)));
	mountain4VAO.LinkAttrib(mountain4VBO, 2, 2, GL_FLOAT, 11 * sizeof(float), (void*)(6 * sizeof(float)));
	mountain4VAO.LinkAttrib(mountain4VBO, 3, 3, GL_FLOAT, 11 * sizeof(float), (void*)(8 * sizeof(float)));
	mountain4VAO.Unbind();
	mountain4VAO.Unbind();
	mountain4VAO.Unbind();

	// Shader for light cube
	Shader lightShader("light.vert", "light.frag");

	// Generates VAO, VBO, EBO, and binds / unbinds all for the light cube
	VAO lightVAO;
	lightVAO.Bind();
	VBO lightVBO(lightVertices, sizeof(lightVertices));
	EBO lightEBO(lightIndices, sizeof(lightIndices));
	lightVAO.LinkAttrib(lightVBO, 0, 3, GL_FLOAT, 3 * sizeof(float), (void*)0);
	lightVAO.Unbind();
	lightVBO.Unbind();
	lightEBO.Unbind();

	// Sets up lighting for OpenGL objects
	glm::vec4 lightColor = glm::vec4(1.0f, 1.0f, 1.0f, 1.0f);
	glm::vec3 lightPos = glm::vec3(0.5f, 0.5f, 0.5f);
	glm::mat4 lightModel = glm::mat4(1.0f);
	lightModel = glm::translate(lightModel, lightPos);
	glm::vec3 pyramidPos = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::mat4 pyramidModel = glm::mat4(1.0f);
	pyramidModel = glm::translate(pyramidModel, pyramidPos);
	lightShader.Activate();
	glUniformMatrix4fv(glGetUniformLocation(lightShader.ID, "model"), 1, GL_FALSE, glm::value_ptr(lightModel));
	glUniform4f(glGetUniformLocation(lightShader.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	shaderProgram.Activate();
	glUniformMatrix4fv(glGetUniformLocation(shaderProgram.ID, "model"), 1, GL_FALSE, glm::value_ptr(pyramidModel));
	glUniform4f(glGetUniformLocation(shaderProgram.ID, "lightColor"), lightColor.x, lightColor.y, lightColor.z, lightColor.w);
	glUniform3f(glGetUniformLocation(shaderProgram.ID, "lightPos"), lightPos.x, lightPos.y, lightPos.z);

	// Set up textures
	Texture oceanTex("waterTexture.jpg", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	oceanTex.texUnit(shaderProgram, "tex0", 0);
	Texture shipTex("shipTexture.jpg", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	shipTex.texUnit(shaderProgram, "tex0", 0);
	Texture mountainTex("mountainTexture.jpg", GL_TEXTURE_2D, GL_TEXTURE0, GL_RGBA, GL_UNSIGNED_BYTE);
	mountainTex.texUnit(shaderProgram, "tex0", 0);

	// Enables the Depth Buffer
	glEnable(GL_DEPTH_TEST);

	// Creates camera object
	Camera camera(width, height, glm::vec3(0.0f, 0.0f, 2.0f));

	// Main while loop
	while (!glfwWindowShouldClose(window)) {

		// Specify the color of the background
		glClearColor(0.07f, 0.13f, 0.17f, 1.0f);

		// Clean the back buffer and depth buffer
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// Handles camera inputs
		camera.Inputs(window);

		// Updates and exports the camera matrix to the Vertex Shader
		camera.updateMatrix(45.0f, 0.1f, 100.0f);

		// Tells OpenGL which Shader Program to use
		shaderProgram.Activate();

		// Exports the camera position to the Fragment Shader for specular lighting
		glUniform3f(glGetUniformLocation(shaderProgram.ID, "camPos"), camera.Position.x, camera.Position.y, camera.Position.z);
		camera.Matrix(shaderProgram, "camMatrix");

		// Binds texture so that is appears in rendering
		oceanTex.Bind();

		// Bind the VAO so OpenGL knows to use it
		oceanVAO.Bind();

		// Draw primitives, number of indices, datatype of indices, index of indices
		glDrawElements(GL_TRIANGLES, sizeof(oceanIndices) / sizeof(int), GL_UNSIGNED_INT, 0);

		oceanVAO.Unbind();
		oceanTex.Unbind();
		shipTex.Bind();
		shipBaseVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(shipBaseIndices) / sizeof(int), GL_UNSIGNED_INT, 0);
		shipBaseVAO.Unbind();
		shipFrontVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(shipFrontIndices) / sizeof(int), GL_UNSIGNED_INT, 0);
		shipFrontVAO.Unbind();
		shipBackVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(shipBackIndices) / sizeof(int), GL_UNSIGNED_INT, 0);
		shipBackVAO.Unbind();
		shipBackVAO.Unbind();
		shipTopVAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(shipTopIndices) / sizeof(int), GL_UNSIGNED_INT, 0);
		shipTopVAO.Unbind();
		shipTex.Unbind();
		mountainTex.Bind();
		mountain1VAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(mountain1Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		mountain1VAO.Unbind();
		mountain2VAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(mountain2Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		mountain2VAO.Unbind();
		mountain3VAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(mountain3Indices) / sizeof(int), GL_UNSIGNED_INT, 0);
		mountain3VAO.Unbind();
		mountain4VAO.Bind();
		glDrawElements(GL_TRIANGLES, sizeof(mountain4Indices) / sizeof(int), GL_UNSIGNED_INT, 0);

		// Tells OpenGL which shader program to use
		lightShader.Activate();

		// Exports the camMatrix to the Vertex Shader of the light cube
		camera.Matrix(lightShader, "camMatrix");

		// Binds the VAO
		lightVAO.Bind();

		// Draws elements
		glDrawElements(GL_TRIANGLES, sizeof(lightIndices) / sizeof(int), GL_UNSIGNED_INT, 0);

		// Swap the back buffer with the front buffer
		glfwSwapBuffers(window);

		// Take care of all GLFW events
		glfwPollEvents();
	}

	// Delete all objects

	// VAOs
	oceanVAO.Delete();
	
	shipBaseVAO.Delete();
	shipFrontVAO.Delete();
	shipBackVAO.Delete();
	mountain1VAO.Delete();
	mountain2VAO.Delete();
	mountain3VAO.Delete();
	mountain4VAO.Delete();

	// VBOs
	oceanVBO.Delete();
	shipBaseVBO.Delete();
	shipFrontVBO.Delete();
	shipBackVBO.Delete();
	mountain1VBO.Delete();
	mountain2VBO.Delete();
	mountain3VBO.Delete();
	mountain4VBO.Delete();

	// EBOs
	oceanEBO.Delete();
	shipBaseEBO.Delete();
	shipFrontEBO.Delete();
	shipBackEBO.Delete();
	mountain1EBO.Delete();
	mountain2EBO.Delete();
	mountain3EBO.Delete();
	mountain4VBO.Delete();

	// Textures
	oceanTex.Delete();
	shipTex.Delete();
	mountainTex.Delete();
	shaderProgram.Delete();

	// Delete window before ending the program
	glfwDestroyWindow(window);

	// Terminate GLFW before ending the program
	glfwTerminate();
	return 0;
}